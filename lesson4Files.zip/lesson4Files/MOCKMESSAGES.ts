
import { Message } from './Message';

export var MOCKMESSAGES: any[] = [
		  { 'id': '1',  'subject': 'Assignment 2', 'text': 'Assignment 2 is due tomorrow', 'sender': 'Instructor' }
		, { 'id': '2',  'subject': 'Angular Routing', 'text': 'Anyone found out how to do routing yet?', 'sender': 'Tom' }
		, { 'id': '3',  'subject': 'Re: Angular Routing', 'text': 'Udemy Angular 2 Routing shows you how', 'sender': 'Bill' }
				
		];

